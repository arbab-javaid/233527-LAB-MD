﻿using System;
using System.Collections.Generic;

abstract class User
{
    public string UserID { get; set; }
    public string Name { get; set; }
    public string PhoneNumber { get; set; }

    public virtual void Register(string name, string phoneNumber)
    {
        UserID = Guid.NewGuid().ToString();
        Name = name;
        PhoneNumber = phoneNumber;
    }

    public virtual void DisplayProfile()
    {
        Console.WriteLine($"User ID: {UserID}, Name: {Name}, Phone: {PhoneNumber}");
    }
}

class Rider : User
{
    public List<Trip> RideHistory { get; set; } = new List<Trip>();

    public void RequestRide(string startLocation, string destination)
    {
        Console.WriteLine("Ride requested successfully!");
        RideHistory.Add(new Trip(this, startLocation, destination));
    }

    public void ViewRideHistory()
    {
        foreach (var trip in RideHistory)
            trip.DisplayTripDetails();
    }
}

class Driver : User
{
    public string DriverID { get; set; }
    public string VehicleDetails { get; set; }
    public bool IsAvailable { get; set; } = true;
    public List<Trip> TripHistory { get; set; } = new List<Trip>();

    public void AcceptRide(Trip trip)
    {
        IsAvailable = false;
        Console.WriteLine($"Driver {Name} accepted the ride request from {trip.RiderName}");
        TripHistory.Add(trip);
    }

    public void ViewTripHistory()
    {
        foreach (var trip in TripHistory)
            trip.DisplayTripDetails();
    }

    public void ToggleAvailability()
    {
        IsAvailable = !IsAvailable;
    }
}

class Trip
{
    public string TripID { get; private set; }
    public string RiderName { get; private set; }
    public string DriverName { get; set; }
    public string StartLocation { get; private set; }
    public string Destination { get; private set; }
    public decimal Fare { get; set; }
    public string Status { get; set; }

    public Trip(Rider rider, string startLocation, string destination)
    {
        TripID = Guid.NewGuid().ToString();
        RiderName = rider.Name;
        StartLocation = startLocation;
        Destination = destination;
        Status = "Requested";
    }

    public void CalculateFare()
    {
        Fare = new Random().Next(10, 50);
    }

    public void StartTrip(string driverName)
    {
        DriverName = driverName;
        Status = "Ongoing";
        CalculateFare();
    }

    public void EndTrip()
    {
        Status = "Completed";
        Console.WriteLine($"Trip from {StartLocation} to {Destination} has been completed. Fare: ${Fare}");
    }

    public void DisplayTripDetails()
    {
        Console.WriteLine($"TripID: {TripID}, From: {StartLocation}, To: {Destination}, Fare: ${Fare}");
    }
}

class RideSharingSystem
{
    public List<Rider> RegisteredRiders { get; set; } = new List<Rider>();
    public List<Driver> RegisteredDrivers { get; set; } = new List<Driver>();
    public List<Trip> AvailableTrips { get; set; } = new List<Trip>();

    public void RegisterUser(string userType, string name, string phoneNumber)
    {
        if (userType == "Rider")
        {
            var rider = new Rider();
            rider.Register(name, phoneNumber);
            RegisteredRiders.Add(rider);
            Console.WriteLine("Registered successfully as a Rider!");
        }
        else if (userType == "Driver")
        {
            var driver = new Driver { DriverID = Guid.NewGuid().ToString() };
            driver.Register(name, phoneNumber);
            RegisteredDrivers.Add(driver);
            Console.WriteLine("Registered successfully as a Driver!");
        }
    }

    public void RequestRide(string riderName, string startLocation, string destination)
    {
        var rider = RegisteredRiders.Find(r => r.Name == riderName);
        if (rider != null)
        {
            rider.RequestRide(startLocation, destination);
            AvailableTrips.Add(new Trip(rider, startLocation, destination));
        }
    }

    public void FindAvailableDriver()
    {
        foreach (var trip in AvailableTrips)
        {
            var driver = RegisteredDrivers.Find(d => d.IsAvailable);
            if (driver != null)
            {
                driver.AcceptRide(trip);
                trip.StartTrip(driver.Name);
                driver.ToggleAvailability();
                AvailableTrips.Remove(trip);
                break;
            }
        }
    }

    public void CompleteTrip(string tripId)
    {
        foreach (var driver in RegisteredDrivers)
        {
            var trip = driver.TripHistory.Find(t => t.TripID == tripId);
            if (trip != null)
            {
                trip.EndTrip();
                driver.ToggleAvailability();
                break;
            }
        }
    }

    public void DisplayAllTrips()
    {
        foreach (var driver in RegisteredDrivers)
            foreach (var trip in driver.TripHistory)
                trip.DisplayTripDetails();
    }
}

class Program
{
    static void Main(string[] args)
    {
        var system = new RideSharingSystem();

        while (true)
        {
            Console.WriteLine("\nWelcome to the Ride-Sharing System");
            Console.WriteLine("1. Register as Rider\n2. Register as Driver\n3. Request a Ride (Rider)");
            Console.WriteLine("4. Accept a Ride (Driver)\n5. Complete a Trip\n6. View Ride History (Rider)");
            Console.WriteLine("7. View Trip History (Driver)\n8. Display All Trips\n9. Exit");
            Console.Write("Please choose an option: ");
            int option = int.Parse(Console.ReadLine());

            switch (option)
            {
                case 1:
                    Console.Write("Enter your name: ");
                    string riderName = Console.ReadLine();
                    Console.Write("Enter your phone number: ");
                    string riderPhone = Console.ReadLine();
                    system.RegisterUser("Rider", riderName, riderPhone);
                    break;
                case 2:
                    Console.Write("Enter your name: ");
                    string driverName = Console.ReadLine();
                    Console.Write("Enter your phone number: ");
                    string driverPhone = Console.ReadLine();
                    system.RegisterUser("Driver", driverName, driverPhone);
                    break;
                case 3:
                    Console.Write("Enter your name: ");
                    string requesterName = Console.ReadLine();
                    Console.Write("Enter your current location: ");
                    string start = Console.ReadLine();
                    Console.Write("Enter your destination: ");
                    string destination = Console.ReadLine();
                    system.RequestRide(requesterName, start, destination);
                    break;
                case 4:
                    system.FindAvailableDriver();
                    break;
                case 5:
                    Console.Write("Enter Trip ID to complete: ");
                    string tripId = Console.ReadLine();
                    system.CompleteTrip(tripId);
                    break;
                case 6:
                    Console.Write("Enter your name: ");
                    string viewRiderName = Console.ReadLine();
                    var rider = system.RegisteredRiders.Find(r => r.Name == viewRiderName);
                    rider?.ViewRideHistory();
                    break;
                case 7:
                    Console.Write("Enter your name: ");
                    string viewDriverName = Console.ReadLine();
                    var driver = system.RegisteredDrivers.Find(d => d.Name == viewDriverName);
                    driver?.ViewTripHistory();
                    break;
                case 8:
                    system.DisplayAllTrips();
                    break;
                case 9:
                    return;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }
        }
    }
}

